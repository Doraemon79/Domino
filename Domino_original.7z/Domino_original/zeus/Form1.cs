﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zeus
{
    public partial class Form1 : Form
    {
        string title = "", quantity = "", next_job = "";
        private bool work = false;


        

        public Form1()
        {
            InitializeComponent();


            sevenSegmentArray1.Value = "0";
            counter_to_print.Value = long.Parse("0");

        }
        

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_move_up_Click(object sender, EventArgs e)
        {
            MoveUp(listBox1);
        }

        private void btn_move_down_Click(object sender, EventArgs e)
        {
            MoveDown(listBox1);
        }


        void MoveUp(ListBox myListBox)
        {
            int selectedIndex = myListBox.SelectedIndex;
            if (selectedIndex > 0)
            {
                myListBox.Items.Insert(selectedIndex - 1, myListBox.Items[selectedIndex]);
                myListBox.Items.RemoveAt(selectedIndex + 1);
                myListBox.SelectedIndex = selectedIndex - 1;
            }
        }

        void MoveDown(ListBox myListBox)
        {
            int selectedIndex = myListBox.SelectedIndex;
            if (selectedIndex < myListBox.Items.Count - 1 & selectedIndex != -1)
            {
                myListBox.Items.Insert(selectedIndex + 2, myListBox.Items[selectedIndex]);
                myListBox.Items.RemoveAt(selectedIndex);
                myListBox.SelectedIndex = selectedIndex + 1;

            }
        }


        private void btn_stop_Click(object sender, EventArgs e)
        {
            aGauge1.Value = 0;
            sevenSegmentArray1.Value = "0";
            colorSliderCustomThumbTrackBar.Value = 0;
            work = false;
            

        }

        private void btn_add_job_Click(object sender, EventArgs e)
        {
            if ((numericUpDown1.Value > 0)&&(txtbx_book_name.Text!=""))
            {
                string next_job = txtbx_book_name.Text + " , " + numericUpDown1.Value.ToString();
                listBox1.Items.Add(next_job);
                txtbx_book_name.Text = "";
                numericUpDown1.Value = 0;
            }
            else
            {
                MessageBox.Show("The quantity needs to be greater than 0\rThe book must have a title","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            btn_start.Visible = true;
            aGauge1.Value = 0;
            sevenSegmentArray1.Value = "0";
            colorSliderCustomThumbTrackBar.Value = 0;
            string next_job = lbl_progress.Text + " , " + counter_to_print.Value.ToString();
            listBox1.Items.Insert(0, next_job);
            lbl_progress.Text = "";
            counter_to_print.Value = 0;
        }

        private async void colorSliderCustomThumbTrackBar_MouseUp(object sender, MouseEventArgs e)
        {
            aGauge1.Value = colorSliderCustomThumbTrackBar.Value;
            sevenSegmentArray1.Value = Convert.ToString(aGauge1.Value);

            if (lbl_progress.Text != "")
            {
                if (aGauge1.Value == 0)
                {
                    //do nothing as we are not running
                }
                else
                {
                    for (int i = 0; i < long.Parse(quantity); i++)
                    {
                        if (long.Parse(quantity) > 0)
                        {
                            counter_to_print.Value = counter_to_print.Value - 1;
                            await Task.Delay(TimeSpan.FromMilliseconds(20000/(aGauge1.Value + 1)));
                        }
                    }

                    lbl_progress.Text = "";

                    if (listBox1.Items[0].ToString() != "")
                    {
                        MessageBox.Show("hello");
                    }

                }
            }
        }
       


        private void btn_start_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count > 0)
            {
                next_job = listBox1.Items[0].ToString();

                string[] words = next_job.Split(',');
                title = words[0].ToString();
                quantity = words[1].ToString();

                lbl_progress.Text = title;
                counter_to_print.Value = long.Parse(quantity);

                listBox1.Items.RemoveAt(0);

                work = true;
                btn_start.Visible = false;

            }
            else
            {
                MessageBox.Show("No jobs to available");
            }
        }


        

    }
}
