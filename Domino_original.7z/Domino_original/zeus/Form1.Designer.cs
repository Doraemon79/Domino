﻿namespace zeus
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btn_stop = new QA.Controls.AquaButton();
            this.btn_start = new QA.Controls.AquaButton();
            this.btn_reset = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.btn_close = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.btn_move_up = new System.Windows.Forms.Button();
            this.btn_move_down = new System.Windows.Forms.Button();
            this.txtbx_book_name = new System.Windows.Forms.TextBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_add_job = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.counter_to_print = new CounterLib.Counter();
            this.colorSliderCustomThumbTrackBar = new MB.Controls.ColorSlider();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lbl_progress = new System.Windows.Forms.Label();
            this.sevenSegmentArray1 = new DmitryBrant.CustomControls.SevenSegmentArray();
            this.aGauge1 = new gauges.AGauge();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_stop
            // 
            this.btn_stop.ButtonColour = System.Drawing.Color.Red;
            this.btn_stop.ButtonText = "Stop";
            this.btn_stop.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.btn_stop.FontSize = 24F;
            this.btn_stop.Location = new System.Drawing.Point(908, 159);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(125, 125);
            this.btn_stop.TabIndex = 12;
            this.btn_stop.TextColour = System.Drawing.Color.Black;
            this.btn_stop.Click += new System.EventHandler(this.btn_stop_Click);
            // 
            // btn_start
            // 
            this.btn_start.ButtonColour = System.Drawing.Color.LawnGreen;
            this.btn_start.ButtonText = "Start";
            this.btn_start.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F);
            this.btn_start.FontSize = 24F;
            this.btn_start.Location = new System.Drawing.Point(908, 22);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(125, 125);
            this.btn_start.TabIndex = 13;
            this.btn_start.TextColour = System.Drawing.Color.Black;
            this.btn_start.Click += new System.EventHandler(this.btn_start_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.BackColor = System.Drawing.Color.DodgerBlue;
            this.btn_reset.Dome = true;
            this.btn_reset.Location = new System.Drawing.Point(855, 596);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.RecessDepth = 3;
            this.btn_reset.Size = new System.Drawing.Size(71, 43);
            this.btn_reset.TabIndex = 18;
            this.btn_reset.Text = "Reset";
            this.btn_reset.UseVisualStyleBackColor = false;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.Red;
            this.btn_close.Dome = true;
            this.btn_close.Location = new System.Drawing.Point(962, 596);
            this.btn_close.Name = "btn_close";
            this.btn_close.RecessDepth = 3;
            this.btn_close.Size = new System.Drawing.Size(71, 43);
            this.btn_close.TabIndex = 17;
            this.btn_close.Text = "Close";
            this.btn_close.UseVisualStyleBackColor = false;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // listBox1
            // 
            this.listBox1.ColumnWidth = 8;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(19, 21);
            this.listBox1.MultiColumn = true;
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(199, 303);
            this.listBox1.TabIndex = 20;
            // 
            // btn_move_up
            // 
            this.btn_move_up.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_move_up.Image = ((System.Drawing.Image)(resources.GetObject("btn_move_up.Image")));
            this.btn_move_up.Location = new System.Drawing.Point(224, 70);
            this.btn_move_up.Name = "btn_move_up";
            this.btn_move_up.Size = new System.Drawing.Size(33, 83);
            this.btn_move_up.TabIndex = 21;
            this.btn_move_up.UseVisualStyleBackColor = true;
            this.btn_move_up.Click += new System.EventHandler(this.btn_move_up_Click);
            // 
            // btn_move_down
            // 
            this.btn_move_down.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_move_down.Image = ((System.Drawing.Image)(resources.GetObject("btn_move_down.Image")));
            this.btn_move_down.Location = new System.Drawing.Point(224, 178);
            this.btn_move_down.Name = "btn_move_down";
            this.btn_move_down.Size = new System.Drawing.Size(33, 83);
            this.btn_move_down.TabIndex = 22;
            this.btn_move_down.UseVisualStyleBackColor = true;
            this.btn_move_down.Click += new System.EventHandler(this.btn_move_down_Click);
            // 
            // txtbx_book_name
            // 
            this.txtbx_book_name.Location = new System.Drawing.Point(41, 22);
            this.txtbx_book_name.Name = "txtbx_book_name";
            this.txtbx_book_name.Size = new System.Drawing.Size(181, 20);
            this.txtbx_book_name.TabIndex = 23;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(60, 48);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(162, 20);
            this.numericUpDown1.TabIndex = 24;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 27;
            this.label1.Text = "Title";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 28;
            this.label2.Text = "Quantity";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_add_job);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.numericUpDown1);
            this.groupBox1.Controls.Add(this.txtbx_book_name);
            this.groupBox1.Location = new System.Drawing.Point(26, 51);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(290, 85);
            this.groupBox1.TabIndex = 29;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Add Job";
            // 
            // btn_add_job
            // 
            this.btn_add_job.Dome = true;
            this.btn_add_job.Location = new System.Drawing.Point(228, 19);
            this.btn_add_job.Name = "btn_add_job";
            this.btn_add_job.RecessDepth = 0;
            this.btn_add_job.Size = new System.Drawing.Size(50, 50);
            this.btn_add_job.TabIndex = 30;
            this.btn_add_job.Text = "Add";
            this.btn_add_job.UseVisualStyleBackColor = true;
            this.btn_add_job.Click += new System.EventHandler(this.btn_add_job_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_move_down);
            this.groupBox2.Controls.Add(this.btn_move_up);
            this.groupBox2.Controls.Add(this.listBox1);
            this.groupBox2.Location = new System.Drawing.Point(26, 291);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(290, 338);
            this.groupBox2.TabIndex = 30;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Jobs List";
            // 
            // counter_to_print
            // 
            this.counter_to_print.Location = new System.Drawing.Point(152, 43);
            this.counter_to_print.Name = "counter_to_print";
            this.counter_to_print.Size = new System.Drawing.Size(75, 20);
            this.counter_to_print.TabIndex = 31;
            this.counter_to_print.ToValue = ((long)(0));
            this.counter_to_print.Value = ((long)(0));
            // 
            // colorSliderCustomThumbTrackBar
            // 
            this.colorSliderCustomThumbTrackBar.BackColor = System.Drawing.Color.Transparent;
            this.colorSliderCustomThumbTrackBar.BarInnerColor = System.Drawing.Color.Red;
            this.colorSliderCustomThumbTrackBar.BarOuterColor = System.Drawing.Color.LightCoral;
            this.colorSliderCustomThumbTrackBar.BarPenColor = System.Drawing.Color.Transparent;
            this.colorSliderCustomThumbTrackBar.BorderRoundRectSize = new System.Drawing.Size(8, 8);
            this.colorSliderCustomThumbTrackBar.ElapsedInnerColor = System.Drawing.Color.Green;
            this.colorSliderCustomThumbTrackBar.ElapsedOuterColor = System.Drawing.Color.LightGreen;
            this.colorSliderCustomThumbTrackBar.LargeChange = ((uint)(5u));
            this.colorSliderCustomThumbTrackBar.Location = new System.Drawing.Point(51, 311);
            this.colorSliderCustomThumbTrackBar.Name = "colorSliderCustomThumbTrackBar";
            this.colorSliderCustomThumbTrackBar.Size = new System.Drawing.Size(254, 25);
            this.colorSliderCustomThumbTrackBar.SmallChange = ((uint)(1u));
            this.colorSliderCustomThumbTrackBar.TabIndex = 33;
            this.colorSliderCustomThumbTrackBar.Text = "/";
            this.colorSliderCustomThumbTrackBar.ThumbInnerColor = System.Drawing.Color.DarkGray;
            this.colorSliderCustomThumbTrackBar.ThumbOuterColor = System.Drawing.Color.Gray;
            this.colorSliderCustomThumbTrackBar.ThumbPenColor = System.Drawing.Color.DimGray;
            this.colorSliderCustomThumbTrackBar.ThumbRoundRectSize = new System.Drawing.Size(2, 2);
            this.colorSliderCustomThumbTrackBar.ThumbSize = 10;
            this.colorSliderCustomThumbTrackBar.Value = 0;
            this.colorSliderCustomThumbTrackBar.MouseUp += new System.Windows.Forms.MouseEventHandler(this.colorSliderCustomThumbTrackBar_MouseUp);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.sevenSegmentArray1);
            this.groupBox3.Controls.Add(this.colorSliderCustomThumbTrackBar);
            this.groupBox3.Controls.Add(this.aGauge1);
            this.groupBox3.Location = new System.Drawing.Point(394, 22);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(355, 343);
            this.groupBox3.TabIndex = 34;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Print Speed";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 13);
            this.label3.TabIndex = 37;
            this.label3.Text = "Copies still to print";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 13);
            this.label4.TabIndex = 36;
            this.label4.Text = "Title";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lbl_progress);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.counter_to_print);
            this.groupBox4.Location = new System.Drawing.Point(459, 443);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(249, 80);
            this.groupBox4.TabIndex = 38;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Job in Progress";
            // 
            // lbl_progress
            // 
            this.lbl_progress.AutoSize = true;
            this.lbl_progress.Location = new System.Drawing.Point(97, 18);
            this.lbl_progress.Name = "lbl_progress";
            this.lbl_progress.Size = new System.Drawing.Size(0, 13);
            this.lbl_progress.TabIndex = 38;
            // 
            // sevenSegmentArray1
            // 
            this.sevenSegmentArray1.ArrayCount = 4;
            this.sevenSegmentArray1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.sevenSegmentArray1.ColorBackground = System.Drawing.SystemColors.Control;
            this.sevenSegmentArray1.ColorDark = System.Drawing.SystemColors.Control;
            this.sevenSegmentArray1.ColorLight = System.Drawing.Color.Red;
            this.sevenSegmentArray1.DecimalShow = true;
            this.sevenSegmentArray1.ElementPadding = new System.Windows.Forms.Padding(4);
            this.sevenSegmentArray1.ElementWidth = 10;
            this.sevenSegmentArray1.ItalicFactor = 0F;
            this.sevenSegmentArray1.Location = new System.Drawing.Point(132, 260);
            this.sevenSegmentArray1.Name = "sevenSegmentArray1";
            this.sevenSegmentArray1.Size = new System.Drawing.Size(88, 36);
            this.sevenSegmentArray1.TabIndex = 15;
            this.sevenSegmentArray1.TabStop = false;
            this.sevenSegmentArray1.Value = null;
            // 
            // aGauge1
            // 
            this.aGauge1.BaseArcColor = System.Drawing.Color.Gray;
            this.aGauge1.BaseArcRadius = 130;
            this.aGauge1.BaseArcStart = 135;
            this.aGauge1.BaseArcSweep = 270;
            this.aGauge1.BaseArcWidth = 2;
            this.aGauge1.Cap_Idx = ((byte)(1));
            this.aGauge1.CapColors = new System.Drawing.Color[] {
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black,
        System.Drawing.Color.Black};
            this.aGauge1.CapPosition = new System.Drawing.Point(150, 200);
            this.aGauge1.CapsPosition = new System.Drawing.Point[] {
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(150, 200),
        new System.Drawing.Point(150, 130),
        new System.Drawing.Point(10, 10),
        new System.Drawing.Point(10, 10)};
            this.aGauge1.CapsText = new string[] {
        "",
        "Domino",
        "SPEED",
        "",
        ""};
            this.aGauge1.CapText = "Domino";
            this.aGauge1.Center = new System.Drawing.Point(170, 170);
            this.aGauge1.Location = new System.Drawing.Point(6, 19);
            this.aGauge1.MaxValue = 100F;
            this.aGauge1.MinValue = 0F;
            this.aGauge1.Name = "aGauge1";
            this.aGauge1.NeedleColor1 = gauges.AGauge.NeedleColorEnum.Yellow;
            this.aGauge1.NeedleColor2 = System.Drawing.Color.DimGray;
            this.aGauge1.NeedleRadius = 130;
            this.aGauge1.NeedleType = 0;
            this.aGauge1.NeedleWidth = 2;
            this.aGauge1.Range_Idx = ((byte)(0));
            this.aGauge1.RangeColor = System.Drawing.Color.Red;
            this.aGauge1.RangeEnabled = true;
            this.aGauge1.RangeEndValue = 80F;
            this.aGauge1.RangeInnerRadius = 70;
            this.aGauge1.RangeOuterRadius = 80;
            this.aGauge1.RangesColor = new System.Drawing.Color[] {
        System.Drawing.Color.Red,
        System.Drawing.Color.LightGreen,
        System.Drawing.SystemColors.Control,
        System.Drawing.SystemColors.Control,
        System.Drawing.SystemColors.Control};
            this.aGauge1.RangesEnabled = new bool[] {
        true,
        true,
        false,
        false,
        false};
            this.aGauge1.RangesEndValue = new float[] {
        80F,
        100F,
        0F,
        0F,
        0F};
            this.aGauge1.RangesInnerRadius = new int[] {
        70,
        70,
        70,
        70,
        70};
            this.aGauge1.RangesOuterRadius = new int[] {
        80,
        80,
        80,
        80,
        80};
            this.aGauge1.RangesStartValue = new float[] {
        0F,
        80F,
        0F,
        0F,
        0F};
            this.aGauge1.RangeStartValue = 0F;
            this.aGauge1.ScaleLinesInterColor = System.Drawing.Color.Black;
            this.aGauge1.ScaleLinesInterInnerRadius = 73;
            this.aGauge1.ScaleLinesInterOuterRadius = 80;
            this.aGauge1.ScaleLinesInterWidth = 1;
            this.aGauge1.ScaleLinesMajorColor = System.Drawing.Color.Black;
            this.aGauge1.ScaleLinesMajorInnerRadius = 70;
            this.aGauge1.ScaleLinesMajorOuterRadius = 80;
            this.aGauge1.ScaleLinesMajorStepValue = 20F;
            this.aGauge1.ScaleLinesMajorWidth = 2;
            this.aGauge1.ScaleLinesMinorColor = System.Drawing.Color.Gray;
            this.aGauge1.ScaleLinesMinorInnerRadius = 75;
            this.aGauge1.ScaleLinesMinorNumOf = 9;
            this.aGauge1.ScaleLinesMinorOuterRadius = 80;
            this.aGauge1.ScaleLinesMinorWidth = 1;
            this.aGauge1.ScaleNumbersColor = System.Drawing.Color.Black;
            this.aGauge1.ScaleNumbersFormat = null;
            this.aGauge1.ScaleNumbersRadius = 95;
            this.aGauge1.ScaleNumbersRotation = 0;
            this.aGauge1.ScaleNumbersStartScaleLine = 0;
            this.aGauge1.ScaleNumbersStepScaleLines = 1;
            this.aGauge1.Size = new System.Drawing.Size(340, 291);
            this.aGauge1.TabIndex = 0;
            this.aGauge1.Text = "aGauge1";
            this.aGauge1.Value = 0F;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1068, 651);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.btn_close);
            this.Controls.Add(this.btn_start);
            this.Controls.Add(this.btn_stop);
            this.Controls.Add(this.groupBox3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Zeus";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private QA.Controls.AquaButton btn_stop;
        private QA.Controls.AquaButton btn_start;
        private DmitryBrant.CustomControls.SevenSegmentArray sevenSegmentArray1;
        private GaryPerkin.UserControls.Buttons.RoundButton btn_reset;
        private GaryPerkin.UserControls.Buttons.RoundButton btn_close;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button btn_move_up;
        private System.Windows.Forms.Button btn_move_down;
        private System.Windows.Forms.TextBox txtbx_book_name;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private GaryPerkin.UserControls.Buttons.RoundButton btn_add_job;
        private System.Windows.Forms.GroupBox groupBox2;
        private gauges.AGauge aGauge1;
        private CounterLib.Counter counter_to_print;
        private MB.Controls.ColorSlider colorSliderCustomThumbTrackBar;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label lbl_progress;
    }
}

